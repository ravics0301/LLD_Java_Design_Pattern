package com.example.myapplication_coding;

import android.app.Application;

import java.util.ArrayList;

public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
