package com.example.myapplication_coding;

class Solution {

    /*
     * this is first rule by using mathematics formula of sum of n numbers
     * sum = n(n+1)/2;
     * public int missingNumber(int[] nums) {
     * int sum_1 = 0;
     * for(int i = 0; i < nums.length; i++) {
     * sum_1 = sum_1 + nums[i];
     * }
     * int sum_2 = nums.length*(nums.length+1)/2;
     * return sum_2-sum_1;
     * 
     * 
     * }
     */

     // second rule by using cyclic sorting method
     public int missingNumber(int[] nums) {
        int i = 0;
        while(i < nums.length) {
            int correctIndex = nums[i];
            if(nums[i] < nums.length && nums[i] != nums[correctIndex]) {
                int temp = nums[correctIndex];
                nums[correctIndex] = nums[i];
                nums[correctIndex] = temp;
            } else {
                i++;
            }
        }
        if(nums[nums.length] != nums.length) {
            return nums.length;
        }
        for(int j = 0; j < nums.length; j++) {
            if(nums[j] != j) {
                return j;

            }
        }
        return -1;
     }


}