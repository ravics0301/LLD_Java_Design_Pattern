package com.example.myapplication_coding;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class Cyclic_Sort {

    public static void main(String args[]) {

        int[] array = {4,3,2,7,8,2,3,1};
//        row is shorted Matrix column is shorted matrix
//        System.out.println(Arrays.toString(_2dMatrixSearch(_2dArray,100)));
        System.out.println(findDuplicates(array));
    }

    public static int[] cyclicSort(int arr[]) {
        int i = 0;
        while(i < arr.length) {
            int correctIndex = arr[i] - 1;
            if(arr[i] != arr[correctIndex]) {
                swap(arr, i, correctIndex);
            } else {
                i++;
            }
        }

        return arr;
    }

    public static void swap(int[] arr, int first, int second) {
        int temp = arr[second];
        arr[second] = arr[first];
        arr[first] = temp;
    }

    public static int missingNumber(int[] nums) {
        int i = 0;
        while(i < nums.length) {
            int correctIndex = nums[i];
            if(nums[i] < nums.length && nums[i] != nums[correctIndex]) {
                swap(nums, i, correctIndex);
            } else {
                i++;
            }
        }
//        if(nums[nums.length-1] != nums.length) {
//            return nums.length;
//        }
        for(int j = 0; j < nums.length; j++) {
            if(nums[j] != j) {
                return j;

            }
        }
        return nums.length;
    }

    public static List<Integer>  findDisappearedNumbers(int[] nums) {

        int i = 0;
        while(i < nums.length) {
            int correctPositionOfElement = nums[i] - 1;
            if(nums[i] != nums[correctPositionOfElement]) {
                swapElement(nums, i, correctPositionOfElement);
            } else {
                i++;
            }
        }
       return  returnMissingElementArray(nums);


    }
    public static void swapElement(int arr[], int f, int l) {
        int temp = arr[l];
        arr[l] = arr[f];
        arr[f] = temp;
    }

    public static List<Integer> returnMissingElementArray(int arr[]) {
//        HashMap<Integer, Integer> map = new HashMap<>();
        ArrayList<Integer> list = new ArrayList<Integer>();
        for(int i = 0; i < arr.length; i++) {
            if(arr[i] != i+1 ) {
                list.add(i+1);
            }

        }
        return list;
    }


    public static int findDuplicate(int[] nums) {
        int i = 0;
        while(i < nums.length) {
            int c = nums[i];
            if(nums[i] != nums[c]) {
                int temp = nums[c];
                nums[c] = nums[i];
                nums[i] = temp;
            } else {
                i++;
            }
        }
        for(int j = 0; j < nums.length; j++) {
            if(nums[j] != j+1) {
                return nums[j];
            }
        }
        return nums.length;
    }


    public static List<Integer> findDuplicates(int[] nums) {
        int i = 0;
//        if(nums[i] != i+1) {
            while(i < nums.length ) {
                int correct = nums[i]-1;
                if(correct < nums.length && nums[i] != nums[correct]) {
                    int temp = nums[correct];
                    nums[correct] = nums[i];
                    nums[i] = temp;
                } else {
                    i++;
                }
            }

//        } else {
//            i++;
//        }
        return repeatedElementList(nums);

    }
    public static List<Integer> repeatedElementList(int nums[]) {
        ArrayList<Integer> list = new ArrayList<Integer>();
        for(int j = 0; j < nums.length; j++) {
            if(nums[j] != j+1) {
                list.add(nums[j]);
            }
        }
        return list;
    }


}
