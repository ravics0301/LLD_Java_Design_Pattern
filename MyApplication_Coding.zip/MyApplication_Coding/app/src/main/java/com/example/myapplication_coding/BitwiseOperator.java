package com.example.myapplication_coding;

public class BitwiseOperator {
    public static void main(String[] args) {
        int arr[] = {2,3,4,5,6,2,3,4,5};
        int x = 68;
//        System.out.println(isOdd(x));
//        System.out.println(findUniqueNumberUsingXOR(arr));
//        System.out.println(findNumberOfDigitUsingLog(90909988));
        System.out.println(isPrime(7));
    }


    private static boolean isOdd(int x) {
        return (x & 1) == 1;
    }

    private static int findUniqueNumberUsingXOR(int arr[]) {
        // here the concept is we xor all the number then only number will remain which is not duplicate
//        becase a xor a = 0; (in the array all number are duplicate except one number )
//         it is same like array having all number -ve and +ve only one number is not duplicate
//        ex: {2,3,4,5,6,-2,-3,-4,-5} after addition all number will cancel only 6 will remain.
        int unique = 0;
        for(int i = 0; i < arr.length; i++) {
            unique = unique ^ arr[i];
                   }
        return unique;
    }

    private static int findNumberOfDigitUsingLog(int number) {
        int a = (int)(Math.log(number) / Math.log(10))+ 1;
        return a;
    }

    private static boolean isPrime(int num) {
        int c = 2;
        while(c * c <= num) {
            if(num % c == 0) {
                return false;
            } c++;
        }
        return true;
    }
}
