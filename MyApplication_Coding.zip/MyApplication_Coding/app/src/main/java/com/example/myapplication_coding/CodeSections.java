package com.example.myapplication_coding;

import java.util.Arrays;

public class CodeSections {

    public static void main(String args[]) {
        int arrAscending[] = {1, 2, 3, 4, 5, 9, 12, 32, 33, 44, 55, 66};// ascending  order array
        int arrDescending[] = {66, 55, 44, 33, 21, 11, 8, 7, 5, 3, 1};// ascending  order array
//        int value = repeatedNumber(arr);
//        System.out.println(value);
        int[] digits = {1235, 3453, 33, -36, 454, 5555, 666666, 6890};
//        int totalNumber = countNumberOfDigitHavingEvenNumber(digits);
//        System.out.println(totalNumber);
        int[][] accountArray = {{1, 2, 5}, {9, 0, 8}, {5, 3, 72}, {4, 4, 5, 8, 19}, {2, 33, 456, 78}};
//        /* maximum wealth of customer/*
//        int totalWealth = maxWeathOfPerson(accountArray);
//        System.out.println("total Wealth: "+totalWealth);
        // find out the target element from the 2D array;
//        int[] foundValue = getTheTagetElementFromAnArray(accountArray, 72);
//        System.out.println(Arrays.toString(foundValue));

        // Binary Search
//        int searchElement = binarySearchForBothAscendingAndDescendingOrder(arrDescending, 44
//        );
//        System.out.println(searchElement);

//        int[] ceilingNumber = {1, 4, 6, 8, 9, 11, 22, 33, 44}; // the number which is just greater or equal to the target;\
//        int ceilingNumberFromAnArray = getCeilingNumber(ceilingNumber,10);
//        System.out.println(ceilingNumberFromAnArray);

//        int[] FloorNumber = {3, 4, 6, 8, 9, 11, 22, 33, 44}; // the number which is just greater or equal to the target;\
//        int FloorNumberFromAnArray = getFloorNumber(FloorNumber,2);
//        System.out.println(FloorNumberFromAnArray);
//        int[] array = {2,0,1,3};
//        int missingNumber = missingNumber(array);
//        System.out.println(missingNumber);
//        int[] nElementArray = {3, 5, 7, 9, 10, 90, 100, 130, 140, 160, 170};
//        System.out.println(ans(nElementArray,160));

//        int[] findInMountainArray = {0,1,3,4,5,3,1};
//
//        System.out.println(findInMountainArray(1, findInMountainArray));

    }

    private int pivot(int[] arr) {
        int start  = 0;
        int end = arr.length-1;
        while(start <= end) {
            int mid = start + (end - start)/2;
            if(arr[start] < arr[mid]) {
                start = mid+1;
            } else if(arr[start] >= arr[mid]) {
                end = mid-1;
            } else if(mid > start && arr[mid] < arr[mid-1]) {
                return mid-1;
            }
            else if(mid < end && arr[mid] > arr[mid + 1]) {
                return mid;
            }
        }
        return -1;
    }

    public static int findInMountainArray(int target, int[] mountainArr) {
        int peak = findThePeakElement(mountainArr);
        int element = binarySearchLefSideFromPeak(target, mountainArr, 0, peak);
        if(element == -1) {
            element = binarySearchRightSideFromPeak(target, mountainArr, peak+1,
                    mountainArr.length-1);
        }
        return element;
    }

    private static int binarySearchRightSideFromPeak(int target,int[] mountainArr,
                             int start, int end) {
        while(start <= end ){
            int mid = start + (end -start ) / 2;
            if(mountainArr[mid] > target) {
                start  = mid + 1;
            } else if(mountainArr[mid] <  target)
            {
                end = mid -1;
            } else {
                return mid;
            }
        }
        return -1;

    }
    private static int binarySearchLefSideFromPeak(int target,int[] mountainArr,
                                                    int start, int end) {
        while(start <= end ){
            int mid = start + (end -start ) / 2;
            if(mountainArr[mid] > target) {
                end  = mid -1;
            } else if(mountainArr[mid] <  target)
            {
                start = mid + 1;
            } else {
                return mid;
            }
        }
        return -1;

    }

    private static int findThePeakElement(int[] arr) {
        int start = 0;
        int end = arr.length-1;
        while(start < end) {
            int mid = start + (end - start)/2;
            if(arr[mid] > arr[mid+1]) {
                end = mid;
            } else if(arr[mid] < arr[mid+1]) {
                start = mid+1;
            }
            else {
                return start;
            }
        }
        return start;
    }




   // infinite array having a target element;


   private static int ans(int[] nums, int target) {
        int start = 0;
        int end = 1;
        while(target > nums[end]) {
            int newStart = end+1;
            // end = previous End + sizeOfBox*2(we are doing this because we want to know the length of the chunks where our
            // target element will lie because it is infinite array and we dont know the size of the array)
            end = end + (end - start + 1)*2;
            start = newStart;
        }
        return binarySearchForFindingTheElementFromInfiniteArray(nums, target, start, end);
   }

   private static int binarySearchForFindingTheElementFromInfiniteArray(int[] array, int target, int start, int end) {

        while(start <= end) {
            int m = start + (end - start)/2;
            if(target > array[m]) {
                start = m +1;
            } else if(target < array[m]) {
                end = m - 1;
            }
            else {
                return  m;
            }
        }
        return -1;
   }


    public static int missingNumber(int[] nums) {
        int sum_1 = 0;
        for(int i = 0; i < nums.length; i++) {
            sum_1 = sum_1 + nums[i];
        }
        int sum_2 = nums.length*(nums.length + 1) /2;
        return sum_2-sum_1;


    }

    // find the Floor number from the array (equal or just less of the target)
    private static int getFloorNumber(int [] FloorArray, int target) {
        int startElement = 0;
        char[] letter =  {'c','c','c'};
        int lastElement = FloorArray.length -1;
        if(target < FloorArray[startElement]) {
            return  -1;
        }
        while(startElement <= lastElement) {
            int midElement = startElement + (lastElement - startElement) /2;
            if(FloorArray[midElement] == target) {
                return midElement;
            }
            if(target > FloorArray[midElement]) {
                startElement = midElement +1;
            } else if(target < FloorArray[midElement]) {
                lastElement = midElement -1;
            }
        }
        return lastElement;
    }

// find the ceil of the target (equal or just greater of the target)
    private static int getCeilingNumber(int [] ceilingNumber, int target) {
        int startElement = 0;
        int lastElement = ceilingNumber.length -1;
        if(target > ceilingNumber[lastElement]) {
            return -1;
        }
        while(startElement <= lastElement) {
            int midElement = startElement + (lastElement - startElement) /2;
            if(ceilingNumber[midElement] == target) {
                return midElement;
            }
            if(target > ceilingNumber[midElement]) {
                startElement = midElement +1;
            } else if(target < ceilingNumber[midElement]) {
                lastElement = midElement -1;
            }
        }
        return startElement;
    }
// this method will be right if array is ascending order
    private static int binarySearch(int[] array, int targetElement) {
        if (array.length == 0) {
            return -1;
        }
        int startIndex = 0;
        int lastIndex = array.length - 1;
        while (startIndex <= lastIndex) {
            int midElement = (startIndex + lastIndex) / 2;
            if (array[midElement] > targetElement) {
                lastIndex = midElement - 1;

            } else if (array[midElement] < targetElement) {
                startIndex = midElement + 1;
            } else {
                return midElement;

            }
        }
        return -1;
    }

    private static int binarySearchForBothAscendingAndDescendingOrder(int[] array, int targetElement) {

        if(array.length == 0) {
            return -1;
        }
        int startElement = 0;
        int lastElement = array.length -1;
        while(startElement <= lastElement) {
            int midElement = startElement + (lastElement - startElement) / 2;

            if(targetElement == array[midElement]) {
                return midElement;
            }
            if (array[startElement] < array[lastElement]) {
                if(targetElement > array[midElement]) {
                    startElement = midElement +1;
                } else if(targetElement < array[midElement]) {
                    lastElement = midElement -1;
                }

            } else {
                if(targetElement > array[midElement]) {
                    lastElement = midElement -1;
                } else if(targetElement < array[midElement]) {
                    startElement = midElement +1;
                }
            }
        }
        return -1;
    }

    private static int[] getTheTagetElementFromAnArray(int[][] arrayOfElement, int targetElement) {
//        int elementFound = -1;
        for (int i = 0; i < arrayOfElement.length; i++) {
            for (int j = 0; j < arrayOfElement[i].length; j++) {
                if (targetElement == arrayOfElement[i][j]) {
                    return new int[]{i, j};
                }
            }
        }
        return new int[]{-1, -1};
    }

    private static int repeatedNumber(int arr[]) {
        if (arr.length > 0) {
            int first_element = 0;
            int last_element = arr.length - 1;
            while (first_element < last_element) {
                if (arr[first_element] == arr[last_element]) {
                    System.out.println("repeated element is: " + arr[first_element]);

                }
                first_element++;
                last_element--;
            }
        }
        return arr.length;

    }

    // count total number of digit having even number from the array.
    private static int countNumberOfDigitHavingEvenNumber(int[] array) {
        int totalNumber = 0;
        if (array.length > 0) {
            for (int i = 0; i < array.length; i++) {

                if (isNumberEven(array[i])) {
                    totalNumber++;
                }
            }
        }


        return totalNumber;
    }

    private static boolean isNumberEven(int number) {
        boolean isNumberEven = false;
        int count = 0;
        // make the number +ve
        if (number < 0) {
            number = number * -1;
        }
        while (number > 0) {
            number = number / 10;
            count++;
        }
        if (count % 2 == 0) {
            isNumberEven = true;
        }
        return isNumberEven;
    }

    private static int maxWeathOfPerson(int[][] array) {
        int maxWealth = 0;
        for (int i = 0; i < array.length; i++) {
            int temp_maxWealth = getWealth(array[i]);
            if (maxWealth < temp_maxWealth) {
                maxWealth = temp_maxWealth;
                System.out.println("Max Wealth: " + maxWealth);
            }
        }

        return maxWealth;
    }

    private static int getWealth(int[] arrayOfAccount) {
        int maxWealth = 0;
        for (int i = 0; i < arrayOfAccount.length; i++) {
            maxWealth += arrayOfAccount[i];
            System.out.println("Wealth= " + maxWealth);
        }


        return maxWealth;
    }

}
