package com.example.myapplication_coding;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

public class _2DArraySearch {

    public static void main(String args[]) {
        int _2dArray[][] = new int[][]{{1,2,3,4},
                {5,8,11,14},{9,10,12,15}};
        int[] array = {1,3,4,5,-1};
//        row is shorted Matrix column is shorted matrix
//        System.out.println(Arrays.toString(_2dMatrixSearch(_2dArray,100)));
        System.out.println(Arrays.toString(selectionSort(array)));
    }

    static int[] _2dMatrixSearch(int[][] matrix, int targetElement) {
        int row = 0;
        int column = matrix.length-1;
        int x_column= matrix[0].length;
        int x_row= matrix.length;
        System.out.println("Row : "+ x_row + "\n" + " Column : " + matrix[x_row-1][x_column-1]);
        if(targetElement < matrix[x_row-1][x_column-1]) {
            while (row < matrix.length && column >= 0) {
                if (matrix[row][column] == targetElement) {
                    return new int[]{row, column};
                }
                if (matrix[row][column] < targetElement) {
                    row++;
                }
                if (matrix[row][column] > targetElement) {
                    column--;
                }
            }
        }
        return new int[]{-1,-1};
    }

    public static int[] bubbleSort(int[] array) {
        boolean isElementSwapped = false;
        for(int i = 0; i < array.length; i++) {

            for(int j = 1; j < array.length - i-1; j++) {
                if(array[j] < array[j-1]) {
                    int temp = array[j];
                    array[j] = array[j-1];
                    array[j-1] = temp;
                    isElementSwapped = true;
                }
            }
            if(!isElementSwapped) {
                System.out.println("element not swapped so array is sorted");
                break;
            }
        }
        return array;
    }

    public static int[] selectionSort(int[] array) {
        for(int i = 0; i < array.length; i++) {
            int last = array.length-i-1;
           int maxElementFound =  maxElement(array, 0, last);
           swapElement(array, maxElementFound, last);

        }
        return array;
    }
    static int maxElement(int arr[], int start, int end) {
        int max = start;
        for(int i = start; i <= end; i++) {
            if(arr[i] > arr[max]) {
                max = i;
            }
        }
        return max;
    }
    static void swapElement(int arr[], int first, int second) {
        int temp = arr[first];
        arr[first] = arr[second];
        arr[second] = temp;
        System.out.println(Arrays.toString(arr));

    }


/* print a number from N to 1 using recursion*/


}
