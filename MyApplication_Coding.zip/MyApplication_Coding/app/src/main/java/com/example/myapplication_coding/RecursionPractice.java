package com.example.myapplication_coding;

public class RecursionPractice {

    public static void main(String args[]) {
        funReverse(5);
    }

/* print a number from N to 1 using recursion*/

    static void printNto1(int n) {
        if(n==0) {
            return;
        }
        System.out.println(n);
        printNto1(n-1);
    }

    static void funReverse(int n) {
        if(n==0) {
            return;
        }
        funReverse(n-1);
        System.out.println(n);
    }
}
