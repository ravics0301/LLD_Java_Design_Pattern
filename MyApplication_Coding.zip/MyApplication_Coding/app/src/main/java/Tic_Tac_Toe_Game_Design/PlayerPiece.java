package Tic_Tac_Toe_Game_Design;

public class PlayerPiece {
    PlayerType type;

    public PlayerPiece(PlayerType type) {
        this.type = type;

    }
}
