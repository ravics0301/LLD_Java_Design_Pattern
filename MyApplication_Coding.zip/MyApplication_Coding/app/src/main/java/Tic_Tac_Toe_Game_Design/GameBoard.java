package Tic_Tac_Toe_Game_Design;

public class GameBoard {
    int [][] board;
    int boardSize;

    public GameBoard(int bordSize,Players[] players) {
        this.boardSize = bordSize;
    }
}
