package Tic_Tac_Toe_Game_Design;

public class PlayerX extends PlayerPiece{
    public PlayerX() {
        super(PlayerType.X);
    }
}
