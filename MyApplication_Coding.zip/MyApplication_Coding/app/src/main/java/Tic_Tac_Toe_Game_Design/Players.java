package Tic_Tac_Toe_Game_Design;

public class Players {
    int id;
    String name;
    char Symbol;
}
