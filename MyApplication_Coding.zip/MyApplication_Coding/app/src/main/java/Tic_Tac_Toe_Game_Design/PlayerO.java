package Tic_Tac_Toe_Game_Design;

public class PlayerO extends PlayerPiece{
    public PlayerO() {
        super(PlayerType.O);
    }
}
