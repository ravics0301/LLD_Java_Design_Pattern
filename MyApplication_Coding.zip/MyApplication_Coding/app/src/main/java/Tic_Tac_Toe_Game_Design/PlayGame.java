package Tic_Tac_Toe_Game_Design;

public class PlayGame {
    public static void main(String[] args) {
        Players p1 = new Players();
        p1.name = "Ravi";
        p1.Symbol = 'X';

        Players p2 = new Players();
        p2.name = "Sumit";
        p2.id = 2;
        p2.Symbol = 'O';
    }


}
