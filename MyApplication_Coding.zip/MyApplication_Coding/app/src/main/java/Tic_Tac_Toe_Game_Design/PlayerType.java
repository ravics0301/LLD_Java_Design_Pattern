package Tic_Tac_Toe_Game_Design;

public enum PlayerType {
    X , O;
}
