package AbstractFactoryDesignPattern.DesignatedFactory;

import AbstractFactoryDesignPattern.EmployeeType.Manager;
import AbstractFactoryDesignPattern.EmployeeType.Employee;

public class ManagerFactory extends AbstractEmployeeFactory {
    @Override
    public Employee getEmployeeObject() {
        return new Manager();
    }
}
