package AbstractFactoryDesignPattern.DesignatedFactory;

import AbstractFactoryDesignPattern.EmployeeType.AndroidDeveloper;
import AbstractFactoryDesignPattern.EmployeeType.Employee;

public class AndroidDeveloperFactory extends AbstractEmployeeFactory {
    @Override
    public Employee getEmployeeObject() {
        return new AndroidDeveloper();
    }
}
