package AbstractFactoryDesignPattern.DesignatedFactory;

import AbstractFactoryDesignPattern.EmployeeType.Employee;

abstract public class AbstractEmployeeFactory {
    abstract  public Employee getEmployeeObject();
}
