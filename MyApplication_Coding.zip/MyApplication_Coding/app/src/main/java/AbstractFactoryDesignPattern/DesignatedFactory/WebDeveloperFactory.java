package AbstractFactoryDesignPattern.DesignatedFactory;

import AbstractFactoryDesignPattern.EmployeeType.WebDeveloper;
import AbstractFactoryDesignPattern.EmployeeType.Employee;

public class WebDeveloperFactory extends AbstractEmployeeFactory {
    @Override
    public Employee getEmployeeObject() {
        return new WebDeveloper();
    }
}
