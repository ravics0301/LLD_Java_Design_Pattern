package AbstractFactoryDesignPattern.EmployeeType;

public class WebDeveloper implements Employee {
    @Override
    public int getSalary() {
        return 45000;
    }

    @Override
    public String getDesignation() {
        return "Web Developer";
    }
}
