package AbstractFactoryDesignPattern.EmployeeType;

public class AndroidDeveloper implements Employee {
    @Override
    public int getSalary() {
        return 50000;
    }

    @Override
    public String getDesignation() {
        return "Android Developer";
    }
}
