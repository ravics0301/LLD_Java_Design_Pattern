package AbstractFactoryDesignPattern.EmployeeType;

public interface Employee {
    int getSalary();
    String getDesignation();
}
