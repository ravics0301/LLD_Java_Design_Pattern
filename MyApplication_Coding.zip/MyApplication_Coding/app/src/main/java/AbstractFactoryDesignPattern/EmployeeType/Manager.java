package AbstractFactoryDesignPattern.EmployeeType;

public class Manager implements Employee {
    @Override
    public int getSalary() {
        return 80000;
    }

    @Override
    public String getDesignation() {
        return "Manager";
    }
}