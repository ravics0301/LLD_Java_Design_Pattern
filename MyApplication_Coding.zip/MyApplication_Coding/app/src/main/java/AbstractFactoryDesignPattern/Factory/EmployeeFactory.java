package AbstractFactoryDesignPattern.Factory;

import AbstractFactoryDesignPattern.DesignatedFactory.AbstractEmployeeFactory;
import AbstractFactoryDesignPattern.EmployeeType.Employee;

public class EmployeeFactory {

    public static Employee getEmployee(AbstractEmployeeFactory abstractEmployeeFactory) {
        return abstractEmployeeFactory.getEmployeeObject();
    }
}
