package AbstractFactoryDesignPattern;

import AbstractFactoryDesignPattern.EmployeeType.Employee;
import AbstractFactoryDesignPattern.Factory.EmployeeFactory;
import AbstractFactoryDesignPattern.DesignatedFactory.AndroidDeveloperFactory;
import AbstractFactoryDesignPattern.DesignatedFactory.ManagerFactory;
import AbstractFactoryDesignPattern.DesignatedFactory.WebDeveloperFactory;

public class MainClass {
    public static void main(String[] args) {
        Employee emp1 = EmployeeFactory.getEmployee(new AndroidDeveloperFactory());
        System.out.println(emp1.getDesignation());
        Employee emp2  = EmployeeFactory.getEmployee(new WebDeveloperFactory());
        System.out.println(emp2.getDesignation());
        Employee emp3 = EmployeeFactory.getEmployee(new ManagerFactory());
        System.out.println(emp3.getDesignation());
    }
}
