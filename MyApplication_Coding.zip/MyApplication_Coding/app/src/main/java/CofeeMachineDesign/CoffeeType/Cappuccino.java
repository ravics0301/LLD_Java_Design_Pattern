package CofeeMachineDesign.CoffeeType;

import CofeeMachineDesign.PlainCoffee;

public class Cappuccino extends PlainCoffee {
    @Override
    public int getCost() {
        return 130;
    }

    @Override
    public String getDescription() {
        return "This is Cappuccino coffee.";
    }
}
