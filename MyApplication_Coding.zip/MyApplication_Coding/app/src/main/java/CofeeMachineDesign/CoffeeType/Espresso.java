package CofeeMachineDesign.CoffeeType;

import CofeeMachineDesign.PlainCoffee;

public class Espresso extends PlainCoffee {
    @Override
    public int getCost() {
        return 100;
    }

    @Override
    public String getDescription() {
        return "This is Espresso coffee.";
    }
}