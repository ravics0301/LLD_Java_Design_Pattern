package CofeeMachineDesign.CoffeeType;

import CofeeMachineDesign.PlainCoffee;

public class Latte extends PlainCoffee {
    @Override
    public int getCost() {
        return 120;
    }

    @Override
    public String getDescription() {
        return "This is Latte coffee.";
    }
}
