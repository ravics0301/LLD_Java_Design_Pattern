package CofeeMachineDesign;

public abstract class PlainCoffee {
    public abstract int getCost();
    public abstract String getDescription();
}
