package CofeeMachineDesign;

import CofeeMachineDesign.CoffeeDecorator.AddOns.Cream;
import CofeeMachineDesign.CoffeeDecorator.AddOns.Milk;
import CofeeMachineDesign.CoffeeType.Cappuccino;
import CofeeMachineDesign.CoffeeDecorator.AddOns.Sugar;
import CofeeMachineDesign.CoffeeDecorator.Decorator;

public class OrderCoffee {
    public static void main(String[] args) {
        PlainCoffee plainCoffee = new Cappuccino();
        Decorator sugarCoffee = new Sugar(plainCoffee);
        Decorator milk = new Milk(plainCoffee);
        Decorator cream = new Cream(plainCoffee);
        System.out.println("base coffee price: "+ plainCoffee.getCost());
        System.out.println("sugar price: "+ sugarCoffee.getAddOnsPrice());
        System.out.println("base coffee + sugar: "+ sugarCoffee.getCost());
        System.out.println("base coffee + sugar + milk + cream: "+ (plainCoffee.getCost()+milk.getAddOnsPrice()+sugarCoffee.getAddOnsPrice()+cream.getAddOnsPrice()));

    }
}
