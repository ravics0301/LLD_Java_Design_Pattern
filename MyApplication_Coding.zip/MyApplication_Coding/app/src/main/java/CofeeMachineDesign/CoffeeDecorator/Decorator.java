package CofeeMachineDesign.CoffeeDecorator;

import CofeeMachineDesign.PlainCoffee;

public abstract class Decorator extends PlainCoffee {
    public abstract int getAddOnsPrice();
}
