package CofeeMachineDesign.CoffeeDecorator.AddOns;

import CofeeMachineDesign.CoffeeDecorator.Decorator;
import CofeeMachineDesign.PlainCoffee;

public class Sugar extends Decorator {
    PlainCoffee coffee;

    public Sugar(PlainCoffee coffee) {
        this.coffee = coffee;
    }
    @Override
    public int getCost() {
        return coffee.getCost()+getAddOnsPrice();
    }

    @Override
    public String getDescription() {
        return "Sugar has added";
    }

    @Override
    public int getAddOnsPrice() {
        return 5;
    }
}
