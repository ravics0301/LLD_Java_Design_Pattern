package CofeeMachineDesign.CoffeeDecorator.AddOns;

import CofeeMachineDesign.CoffeeDecorator.Decorator;
import CofeeMachineDesign.PlainCoffee;

public class Cream extends Decorator {
    PlainCoffee coffee;

   public Cream(PlainCoffee coffee) {
        this.coffee = coffee;
    }
    @Override
    public int getCost() {
        return coffee.getCost()+getAddOnsPrice();
    }

    @Override
    public String getDescription() {
        return "Cream has added";
    }

    @Override
    public int getAddOnsPrice() {
        return 30;
    }
}
