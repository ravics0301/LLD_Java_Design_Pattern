package CofeeMachineDesign.CoffeeDecorator.AddOns;

import CofeeMachineDesign.CoffeeDecorator.Decorator;
import CofeeMachineDesign.PlainCoffee;

public class Milk extends Decorator {
    PlainCoffee coffee;

   public Milk(PlainCoffee coffee) {
        this.coffee = coffee;
    }
    @Override
    public int getCost() {
        return coffee.getCost()+getAddOnsPrice();
    }

    @Override
    public String getDescription() {
        return "Milk has added";
    }

    @Override
    public int getAddOnsPrice() {
        return 30;
    }
}
