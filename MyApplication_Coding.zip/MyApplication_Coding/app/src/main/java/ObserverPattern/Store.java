package ObserverPattern;


import ObserverPattern.Observable.ObservableImpl;
import ObserverPattern.Observable.ObservableInterface;
import ObserverPattern.Observer.DisplayObserver;
import ObserverPattern.Observer.MobileObserver;
import ObserverPattern.Observer.TVObserver;

public class Store {
    public static void main(String[] args) {
        ObservableInterface observableInterface = new ObservableImpl();
        DisplayObserver observer1 = new TVObserver(observableInterface);
        DisplayObserver observer2 = new MobileObserver(observableInterface);
        DisplayObserver observer3 = new MobileObserver(observableInterface);
        observableInterface.registerObserver(observer1);
        observableInterface.registerObserver(observer2);
        observableInterface.registerObserver(observer3);
        observableInterface.setTemperature(3);

    }
}
