package ObserverPattern.Observable;

import java.util.ArrayList;

import ObserverPattern.Observer.DisplayObserver;

public class ObservableImpl implements ObservableInterface{
    int temperature = 0;
    ArrayList<DisplayObserver> observableInterfaceArrayList = new ArrayList<>();
    @Override
    public void registerObserver(DisplayObserver obj) {
        observableInterfaceArrayList.add(obj);

    }

    @Override
    public void notifyObserver() {
        for (DisplayObserver obj: observableInterfaceArrayList
             )
        {
            obj.update();

        }

    }

    @Override
    public void removeObserver(DisplayObserver obj) {
        observableInterfaceArrayList.remove(obj);

    }

    @Override
    public void setTemperature(int temp) {
        if(this.temperature < temp) {
            this.temperature = temp;
            notifyObserver();
        }

        System.out.println("temp = " + this.temperature);
    }

    @Override
    public int getTemperature() {
        return this.temperature;
    }
}
