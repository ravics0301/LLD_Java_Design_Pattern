package ObserverPattern.Observable;

import ObserverPattern.Observer.DisplayObserver;

public interface ObservableInterface {
    void registerObserver(DisplayObserver obj);
    void notifyObserver();
    void removeObserver(DisplayObserver obj);
    void setTemperature(int temperature);

    int getTemperature();


}
