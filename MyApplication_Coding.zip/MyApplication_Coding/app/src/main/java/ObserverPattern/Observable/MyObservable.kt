package ObserverPattern.Observable

interface MyObservable {
}