package ObserverPattern.Observer;

import ObserverPattern.Observable.ObservableInterface;

public class TVObserver implements DisplayObserver {

    ObservableInterface obj;
   public TVObserver(ObservableInterface obj) {
       this.obj = obj;

    }
    @Override
    public void update() {
        System.out.println("TV Observer update called: "+ obj.getTemperature());
    }
}
