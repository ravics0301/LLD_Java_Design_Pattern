package ObserverPattern.Observer;

import ObserverPattern.Observable.ObservableInterface;

public class MobileObserver implements DisplayObserver {
    ObservableInterface obj;
    public MobileObserver(ObservableInterface obj) {
        this.obj = obj;

    }
    @Override
    public void update() {
        System.out.println("Mobile update called: "+ obj.getTemperature());

    }
}
