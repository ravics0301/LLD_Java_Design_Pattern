package ObserverPattern.Observer;

public interface DisplayObserver {
    void update();
}
