package PizzaCostCalculation.PizzaTopings;

import PizzaCostCalculation.BasePizza;

public class ExtraCheese extends PizzaDecorator{

    private final int toppingCost = 20;
    BasePizza pizza;
    public ExtraCheese(BasePizza pizza) {
        this.pizza = pizza;

    }
    @Override
    public int cost() {
        return pizza.cost()+getToppingCost();
    }

    @Override
    public String getDescription() {
        return pizza.getDescription()+" : with extra Cheese";
    }

    @Override
    public int getToppingCost() {
        return toppingCost;
    }
}
