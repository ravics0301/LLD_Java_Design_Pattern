package PizzaCostCalculation.PizzaTopings;

import PizzaCostCalculation.BasePizza;

public class ExtraPaneer extends PizzaDecorator{
    BasePizza pizza;
    private final int toppingCost = 50;

    public ExtraPaneer(BasePizza pizza) {
        this.pizza = pizza;
    }

    @Override
    public int cost() {
        return pizza.cost()+getToppingCost();
    }

    @Override
    public String getDescription() {
        return pizza.getDescription() + " with extra Paneer";
    }

    @Override
    public int getToppingCost() {
        return toppingCost;
    }
}
