package PizzaCostCalculation.PizzaTopings;

import PizzaCostCalculation.BasePizza;

public abstract class PizzaDecorator extends BasePizza {

    public abstract int getToppingCost();
}
