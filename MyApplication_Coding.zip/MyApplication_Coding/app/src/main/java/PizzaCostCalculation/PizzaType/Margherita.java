package PizzaCostCalculation.PizzaType;

import PizzaCostCalculation.BasePizza;

public class Margherita extends BasePizza {
    @Override
    public int cost() {
        return 200;
    }

    @Override
    public String getDescription() {
        return "This is Margherita Pizza";
    }
}
