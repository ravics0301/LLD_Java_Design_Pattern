package PizzaCostCalculation.PizzaType;

import PizzaCostCalculation.BasePizza;

public class NormalPizza extends BasePizza {
    @Override
    public int cost() {
        return 180;
    }

    @Override
    public String getDescription() {
        return "This is a Normal Pizza";
    }
}
