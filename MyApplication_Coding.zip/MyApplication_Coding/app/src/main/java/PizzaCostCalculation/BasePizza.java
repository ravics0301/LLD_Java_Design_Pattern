package PizzaCostCalculation;

public abstract class BasePizza {
    public abstract int cost();
    public abstract String getDescription();
}
