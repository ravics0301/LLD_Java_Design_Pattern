package PizzaCostCalculation;

import PizzaCostCalculation.PizzaTopings.ExtraCheese;
import PizzaCostCalculation.PizzaTopings.ExtraPaneer;
import PizzaCostCalculation.PizzaTopings.PizzaDecorator;
import PizzaCostCalculation.PizzaType.Margherita;
import PizzaCostCalculation.PizzaType.NormalPizza;

public class OrderPizza {

    public static void main(String[] args) {
        BasePizza normalPizza = new NormalPizza();
        BasePizza margheritaPizza = new Margherita();
        PizzaDecorator margh_Cheese = new ExtraCheese(margheritaPizza);
        PizzaDecorator margh_paneer = new ExtraPaneer(margheritaPizza);
        System.out.println("margh_Cheese + Pizza cost : "+ margh_Cheese.cost());
        System.out.println("margh_paneer cost only : "+ margh_paneer.getToppingCost());


       System.out.println(margh_Cheese.cost()+margh_paneer.getToppingCost());

    }
}
