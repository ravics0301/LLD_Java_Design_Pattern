import java.util.HashMap;
import java.util.Map;
import java.io.*;

public class FindMaximumCount {

//    public static void main(String[] args) {
//        int array[] = {55, 33, 668, 55, 67, 668, 668, 55, 668};
//        System.out.println(getMaximumValue(array));
//
//    }

    private static int getMaximumValue(int[] arr) {
        if (arr.length > 0) {
            return getMaxValue(fillValueInHashMap(arr));


        } else {
            return 0;
        }
    }

    private static Map<Integer, Integer> fillValueInHashMap(int arr[]) {
        Map<Integer, Integer> counts = new HashMap<>();
        int count  = 0;

        for (int i = 0; i < arr.length; i++) {
            if (counts.containsKey(arr[i]))
                 {
                    counts.put(arr[i], counts.get(arr[i])+1);
                } else {
                    counts.put(arr[i], count);
                }

        }
        return counts;

    }

    private static int getMaxValue(Map<Integer, Integer> map) {
        int maxoccurValue = 0;
        int maxMaxValueContainKey = 0;
        if (!map.isEmpty()) {
            for (Map.Entry<Integer, Integer> entry : map.entrySet()) {
                Integer value = entry.getValue();
                if (value != null && value > maxoccurValue) {
                    maxoccurValue = value;
                    maxMaxValueContainKey = entry.getKey();

                }
            }
        }
        return maxMaxValueContainKey;
    }





// second solution without using any java element
        static int findCandidate(int[] arr, int n)
        {
            // using moore's voting algorithm to find the
            // candidate
            int res = 0;
            int count = 1;
            for (int i = 1; i < n; i++) {
                if (arr[i] == arr[res]) {
                    count++;
                }
                else {
                    count--;
                }

                if (count == 0) {
                    res = i;
                    count = 1;
                }
            }
            return arr[res];
        }

        static boolean isMajority(int[] arr, int n,
                                  int candidate)
        {
            // check if candidate is actually the majority
            // element
            int count = 0;
            for (int i = 0; i < n; i++) {
                if (arr[i] == candidate) {
                    count++;
                }
            }
            return count > n / 2;
        }

        // Driver code
        public static void main(String[] args)
        {
//            int[] arr = { 30, 50, 40,40,30,30,7,7,7,7 };
//            int n = arr.length;
//            int candidate = findCandidate(arr, n);
//            if (isMajority(arr, n, candidate)) {
//                System.out.println("Element " + candidate
//                        + " occurs more than "
//                        + n / 2 + " times");
//            }
//            else {
//                System.out.println(
//                        "No element occurs more than " + n / 2
//                                + " times" + candidate);
//            }
            System.out.println(add(3,4,5,6,7));


        }
        public static int add(int... numbers) {
        int sum = 0;
        for (int num : numbers) {
            sum = sum+num;
        }
        return sum;
        }


}
