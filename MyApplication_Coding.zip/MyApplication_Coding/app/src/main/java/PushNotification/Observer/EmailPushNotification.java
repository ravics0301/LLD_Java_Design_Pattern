package PushNotification.Observer;

public class EmailPushNotification implements NotifyObserver {
    String emailId;

    public EmailPushNotification(String emailId) {
        this.emailId = emailId;

    }

    @Override
    public void updateObserver() {
        System.out.println("Email has sent to this emailId: "+this.emailId);

    }
}
