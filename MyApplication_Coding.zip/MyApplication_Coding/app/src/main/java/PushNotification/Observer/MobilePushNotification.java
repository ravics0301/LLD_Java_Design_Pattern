package PushNotification.Observer;

public class MobilePushNotification implements NotifyObserver {
    String mobileNumber;

    public MobilePushNotification(String mobileNumber) {
        this.mobileNumber = mobileNumber;

    }

    @Override
    public void updateObserver() {
        System.out.println("Notification sent to mobile number : "+ mobileNumber);

    }
}
