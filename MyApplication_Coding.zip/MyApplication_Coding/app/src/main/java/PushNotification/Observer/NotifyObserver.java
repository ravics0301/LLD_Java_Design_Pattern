package PushNotification.Observer;

public interface NotifyObserver {
    void updateObserver();
}
