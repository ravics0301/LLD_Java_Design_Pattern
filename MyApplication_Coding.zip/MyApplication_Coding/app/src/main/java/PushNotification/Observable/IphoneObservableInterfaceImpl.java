package PushNotification.Observable;

import java.util.ArrayList;

import PushNotification.Observer.NotifyObserver;

public class IphoneObservableInterfaceImpl implements ObservableInterface {
    int count = 0;
    ArrayList<NotifyObserver> notifyObserversList = new ArrayList<>();

    @Override
    public void registerObserver(NotifyObserver observer) {
        notifyObserversList.add(observer);

    }

    @Override
    public void removeObserver(NotifyObserver observer) {
        notifyObserversList.remove(observer);

    }

    @Override
    public void notifyObserver() {
        for (NotifyObserver obj: notifyObserversList
             ) {
            obj.updateObserver();

        }

    }

    @Override
    public void getData() {

    }

    @Override
    public void setData(int count) {
        if(this.count < count  ) {
            notifyObserver();
        }


    }
}
