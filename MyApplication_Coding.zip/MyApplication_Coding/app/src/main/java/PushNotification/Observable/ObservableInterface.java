package PushNotification.Observable;

import PushNotification.Observer.NotifyObserver;

public interface ObservableInterface {
    void registerObserver(NotifyObserver observer);
    void removeObserver(NotifyObserver observer);
    void notifyObserver();
    void getData();
    void setData(int count);
}
