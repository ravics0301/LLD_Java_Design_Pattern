package PushNotification;

import PushNotification.Observable.IphoneObservableInterfaceImpl;
import PushNotification.Observable.ObservableInterface;
import PushNotification.Observer.EmailPushNotification;
import PushNotification.Observer.MobilePushNotification;

public class Store {
    public static void main(String[] args) {
//        ObservableInterface observableInterface = new ObservableImpl();
//        DisplayObserver observer1 = new TVObserver(observableInterface);
//        DisplayObserver observer2 = new MobileObserver(observableInterface);
//        DisplayObserver observer3 = new MobileObserver(observableInterface);
//        observableInterface.registerObserver(observer1);
//        observableInterface.registerObserver(observer2);
//        observableInterface.registerObserver(observer3);
//        observableInterface.setTemperature(3);

        ObservableInterface observableInterface = new IphoneObservableInterfaceImpl();
        EmailPushNotification observer1 = new EmailPushNotification("xyz@gmail.com");
        MobilePushNotification observer2 = new MobilePushNotification("8587827828");
        observableInterface.registerObserver(observer1);
        observableInterface.registerObserver(observer2);
        observableInterface.setData(5);
    }
}
