package FactoryDesignPatter;

public class EmployeeFactory {

    public static Employee getEmployee(String empType) {
        switch (empType) {
            case "Android" : {
               return new AndroidDeveloper();
            }
            case "Web" : {
               return  new WebDeveloper();
            }
            default:{
                return null;
            }

        }
    }
}
