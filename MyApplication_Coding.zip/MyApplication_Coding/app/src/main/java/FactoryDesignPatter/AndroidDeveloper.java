package FactoryDesignPatter;

public class AndroidDeveloper implements Employee{
    @Override
    public int getSalary() {
        return 50000;
    }
}
