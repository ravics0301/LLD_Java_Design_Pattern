package FactoryDesignPatter;

interface Employee {
    int getSalary();
}
