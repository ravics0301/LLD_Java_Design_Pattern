package FactoryDesignPatter;

public class WebDeveloper implements Employee{
    @Override
    public int getSalary() {
        return 45000;
    }
}
