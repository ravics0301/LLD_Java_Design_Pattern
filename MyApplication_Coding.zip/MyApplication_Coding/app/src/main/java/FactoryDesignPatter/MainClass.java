package FactoryDesignPatter;

public class MainClass {
    public static void main(String[] args) {
        Employee emp1 = EmployeeFactory.getEmployee("Android");
//        if(emp1 !=null ) {
            System.out.println(emp1.getSalary());
//        }
        Employee emp2 = EmployeeFactory.getEmployee("Web");
        System.out.println("WEB: "+emp2.getSalary());
    }
}
